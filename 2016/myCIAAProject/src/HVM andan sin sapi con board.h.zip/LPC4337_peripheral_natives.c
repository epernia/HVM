#include "../../../ostypes.h"
#include "../../../types.h"

#include "sAPI.h"

/* digitalConfig
 * param : [int, int]
 * return: boolean
 */
int16 n_ar_edu_unq_embebidos_DigitalIO_digitalConfig(int32 *sp) {
   pointer self = (pointer)sp[0];
   int32 peripheralID = sp[1];
   int32 mode = sp[2];
   int8 returnValue;

   /*method body has to set returnValue variable */
   returnValue = digitalConfig( (int8)peripheralID, (int8)mode );
   
   sp[0] = (int8) returnValue;
   return -1;
}

/* digitalRead
 * param : [int]
 * return: boolean
 */
int16 n_ar_edu_unq_embebidos_DigitalIO_digitalRead(int32 *sp) {
   pointer self = (pointer)sp[0];
   int32 peripheralID = sp[1];
   int8 returnValue;

   /*method body has to set returnValue variable */
   returnValue = digitalRead( (int8)peripheralID );
   
   sp[0] = (int8) returnValue;
   return -1;
}

/* digitalWrite
 * param : [int, boolean]
 * return: boolean
 */
int16 n_ar_edu_unq_embebidos_DigitalIO_digitalWrite(int32 *sp) {
   pointer self = (pointer)sp[0];
   int32 peripheralID = sp[1];
   int8 value = (int8) sp[2];
   int8 returnValue;

   /*method body has to set returnValue variable */
   returnValue = digitalWrite( (int8)peripheralID, (int8)value );
   
   sp[0] = (int8) returnValue;
   return -1;
}
